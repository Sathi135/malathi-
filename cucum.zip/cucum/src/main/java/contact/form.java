package contact;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class form {
	public static void main (String[]args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "F:\\chrome\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://ditaxpresso.com/#/contactus");
		Thread.sleep(5000);
		driver.findElement(By.name("First Name")).sendKeys("Malathi");
		Thread.sleep(2000);
		driver.findElement(By.name("Last Name")).sendKeys("S");
		Thread.sleep(2000);
		driver.findElement(By.name("Phone")).sendKeys("6366105182");
		Thread.sleep(2000);
		driver.findElement(By.name("Email")).sendKeys("lathaslm1816@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.name("Title")).sendKeys("selenium");
		Thread.sleep(2000);
		driver.findElement(By.name("Description")).sendKeys("selenium training fees");
		Thread.sleep(2000);
		driver.findElement(By.id("formsubmit")).click();
	}
}
		
		
		

