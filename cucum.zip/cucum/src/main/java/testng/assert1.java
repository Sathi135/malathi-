package testng;

public class assert1 {

}
