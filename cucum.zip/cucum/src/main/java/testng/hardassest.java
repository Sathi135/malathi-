package testng;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class hardassest {
	@Test
	public  static void testcase() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "F:\\chrome\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		Thread.sleep(2000);
		String ExceptedTitle = "Demo Web Shop";
		assert.(driver.getTitle(), ExceptedTitle);
		driver.quit();
	}
}
	

	



