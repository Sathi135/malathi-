package testng;

import org.testng.annotations.Test;

public class testng2 {
	@Test(priority=1)
	public void Icecream() {
	System.out.println("Chocolate flavour");
}
    @Test(priority=-1)
    public void Juice() {
    System.out.println("Carrot juice");
    }
    @Test(priority=-1)
    public void Cake() {
    System.out.println("Black forest ");
    }
    }


