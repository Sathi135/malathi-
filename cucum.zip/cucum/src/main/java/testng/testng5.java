package testng;

import org.testng.annotations.Test;

public class testng5 {
	@Test(invocationCount = 3)
	public void login() {
		System.out.println("hello login");
	}
	@Test
	public void logout() { 
	System.out.println("hello logout");
}
}
	



