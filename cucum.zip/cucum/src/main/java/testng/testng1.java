package testng;

import org.testng.annotations.Test;

public class testng1 {
	@Test
	public void sample() {
		System.out.println("hello malu");
	}
	@Test
	public void sample1() {
		System.out.println("hello world");
	}
}
		
	

	



