package testng;

import org.testng.annotations.Test;

public class testng3 {
	@Test(enabled=true,priority=0)
	public void lipstick() {
	System.out.println("mocha shade");
}
  @Test(enabled=false)
  public void eyeliner() {
  System.out.println("blue color");
  }
  @Test(enabled=true,priority=-1)
  public void lotion() {
	  System.out.println("vaseline cocoa");
  }
}
	



