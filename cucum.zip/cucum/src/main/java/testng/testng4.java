package testng;

import org.testng.annotations.Test;

public class testng4 {
	@Test(dependsOnMethods = "loginpage",priority=0)
	public void homepage() {
		System.out.println("hello homepage");
	}
  @Test(priority=2)
  public void loginpage() {
	  System.out.println("loginpage");
  }
  @Test(dependsOnMethods = "homepage")
  public void logoutpage() {
  System.out.println("logoutpage");
  }
}


