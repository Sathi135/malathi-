package testng;

import org.testng.annotations.Test;

public class testngdemo {
	 @Test
	public void sample() {
			System.out.println("hello world");
		}
	}
			
		
	
		
	



