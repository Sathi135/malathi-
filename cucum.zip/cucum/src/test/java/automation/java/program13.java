package automation.java;

import java.io.File;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;

public class program13 {
	public static void main(String[] args) {
		try {
			System.setProperty("webdriver.chrome.driver", "F:\\chrome\\Chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://www.instagram.com/");
			TakesScreenshot ts=(TakesScreenshot) driver;
			Thread.sleep(2000);
			File photo = ts.getScreenshotAs(OutputType.FILE);
			File file=new File("./errorshots/webpage12.png");
			FileUtils.copyFile(photo,file);
			photo.renameTo(file);
		} catch (WebDriverException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


		
	}

		
		
		   
	

		

