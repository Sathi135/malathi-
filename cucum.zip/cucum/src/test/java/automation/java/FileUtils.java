package automation.java;

import java.io.File;

public class FileUtils {

	public static void copyFile(File photo, File file) {
		// TODO Auto-generated method stub
		
	}

}
