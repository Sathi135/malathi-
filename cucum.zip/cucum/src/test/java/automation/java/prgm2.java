package automation.java;

public class prgm2 {

}
