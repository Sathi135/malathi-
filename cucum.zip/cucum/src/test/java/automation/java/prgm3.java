package automation.java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class prgm3 {
	public static void main(String[] args) {
		try {
			System.setProperty("webdriver.chrome.driver", "F:\\chrome\\Chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://www.instagram.com/");
			Thread.sleep(5000);
			driver.findElement(By.name("username")).sendKeys("12345");
			driver.findElement(By.name("password")).sendKeys("4563254");
			driver.findElement(By.xpath("//div[text()='Log in']")).click();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
	}
}
		


