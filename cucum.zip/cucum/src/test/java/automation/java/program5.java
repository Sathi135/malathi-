package automation.java;

public class program5 {

}
