package automation.java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class program12 {
	public static void main(String[] args) {
		try {
			System.setProperty("webdriver.chrome.driver", "F:\\chrome\\Chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://demowebshop.tricentis.com/login");
		    WebElement loginButton = driver.findElement(By.linkText("Log in"));
			loginButton.click();
			WebElement email = driver.findElement(By.id("Email"));
			Thread.sleep(2000);
			WebElement emailTF = null;
			emailTF.clear();
			Thread.sleep(2000);
			email.sendKeys("1234");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
	
	


