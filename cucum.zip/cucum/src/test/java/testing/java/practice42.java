package testing.java;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class practice42 {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "F:\\chrome\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.tripodeal.com/hotels");
		Thread.sleep(2000);
		driver.switchTo().frame("tpcwl_iframe");
		driver.findElement(By.id("hotels-destination-whitelabel_en")).sendKeys("bangalore");
	}
}

