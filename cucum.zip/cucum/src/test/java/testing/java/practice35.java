package testing.java;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class practice35 {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "F:\\chrome\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("file:///C:/Users/User/Desktop/New%20folder/login.html");
		WebElement element = driver.findElement(By.id("username"));
		JavascriptExecutor js= (JavascriptExecutor) driver;
		Thread.sleep(2000);
		js.executeScript("arguments[0].value='this is disabled'",element);
	}
}


