package testing.java;

public class practice50 {

}
