package testing.java;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class practice39 {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "F:\\chrome\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demowebshop.tricentis.com/");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(100,200)");
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(100,200)");
		Thread.sleep(2000);
		js.executeScript("window.scroll.By(100,-200)");
		Thread.sleep(2000);
		js.executeScript("history.go()");
	}
}


