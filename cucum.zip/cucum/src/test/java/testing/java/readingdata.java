package testing.java;

public class readingdata {

}
